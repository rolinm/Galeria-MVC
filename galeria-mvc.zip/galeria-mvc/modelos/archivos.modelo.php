<?php

require_once "conexion.php";

class ModeloArchivos {

	static public function mdlGuardarArchivos($tabla, $datos) {

		$stmt = Conexion::conectar()->prepare("INSERT INTO $tabla(usuario, titulo, foto)VALUES(:usuario, :titulo, :foto)");

		$stmt -> bindParam(":usuario", $datos["usuario"], PDO::PARAM_STR);
		$stmt -> bindParam(":titulo", $datos["titulo"], PDO::PARAM_STR);
		$stmt -> bindParam(":foto", $datos["foto"], PDO::PARAM_STR);

		if ($stmt->execute()) {
			
			return "ok";

		} else {
			
			return print_r(Conexion::conectar()->errorInfo());

		}

		$stmt -> close();

		$stmt = null;

	}

	/*========================================
	=            Mostrar imagenes            =
	========================================*/
	
	static public function mdlMostrarImagenes($tabla, $item, $valor) {

		if ($item != null && $valor != null) {
			
			$stmt = Conexion::conectar()->prepare("SELECT * FROM $tabla WHERE $item = :$item");

			$stmt -> bindParam(":".$item, $valor, PDO::PARAM_STR);

			$stmt -> execute();

			return $stmt ->fetch();

		} else {
			
			$stmt = Conexion::conectar()->prepare("SELECT * FROM $tabla");

			$stmt -> execute();

			return $stmt -> fetchAll();

		}

		$stmt -> close();

		$stmt = null;

	}
	
	/*========================================
	=            actualizar datos            =
	========================================*/
	
	static public function mdlActualizarFoto($tabla, $datos) {

		$stmt = Conexion::conectar()->prepare("UPDATE $tabla SET usuario = :usuario, titulo = :titulo, foto = :foto WHERE usuario = :usuario");

		$stmt -> bindParam(":usuario", $datos["usuario"], PDO::PARAM_STR);
		$stmt -> bindParam(":titulo", $datos["titulo"], PDO::PARAM_STR);
		$stmt -> bindParam(":foto", $datos["foto"], PDO::PARAM_STR);

		if ($stmt->execute()) {
			
			return "ok";

		} else {
			
			return print_r(Conexion::conectar()->errorInfo());

		}

		$stmt -> close();

		$stmt = null;

	}
	
	/*======================================
	=            eliminar fotos            =
	======================================*/
	
	static public function mdlEliminarArchivos($tabla, $datos) {

		$stmt = Conexion::conectar()->prepare("DELETE FROM $tabla WHERE id = :id");

		$stmt -> bindParam(":id", $datos, PDO::PARAM_INT);

		if ($stmt->execute()) {
			
			return "ok";

		} else {
			
			return print_r(Conexion::conectar()->errorInfo());

		}

		$stmt -> close();

		$stmt = null;

		/* 7E1sMkQw>if#xv^8 */
		

	}
	
} 