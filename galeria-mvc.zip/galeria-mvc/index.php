<?php

require_once "controladores/plantilla.controlador.php";

require_once "controladores/archivos.controlador.php";
require_once "modelos/archivos.modelo.php";

$plantilla = new ControladorPlantilla();
$plantilla -> ctrTraerPlantilla();