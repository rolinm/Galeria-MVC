<div class="w3-container w3-padding-32">
	
	<button class="w3-button w3-teal" onclick="document.getElementById('abrirModal').style.display='block'">Agregar Nuevo <i class="fa fa-plus"></i></button>

</div>

<!--=====================================
cuerpo del modal
======================================-->

<div class="w3-modal" id="abrirModal">
	
	<div class="w3-modal-content w3-card-4 w3-animate-zoom" style="max-width: 600px">
		
		<div class="w3-container w3-indigo">
			
			<h2 class="w3-center">Agregar nuevo</h2>

			<span onclick="document.getElementById('abrirModal').style.display='none'" class="w3-btn w3-hover-red w3-display-topright" title="Cerrar modal">&times;</span>

		</div>

		<form class="w3-container" method="post" enctype="multipart/form-data">
			
			<div class="w3-section">
				
				<div class="w3-row-padding">
					
					<div class="">
						
						<label>Título </label>

						<input class="w3-input w3-border w3-hover-border-black" type="text" name="registroTitulo" placeholder="Ingres el título de la imagen" required>

					</div>

				</div>

				<div class="w3-row-padding">
					
					<div class="">
						
						<label>Usuario </label>

						<input class="w3-input w3-border w3-hover-border-black" type="text" name="registroUsuario" placeholder="Ingres el usuario" required>

					</div>

				</div>

				<div class="w3-row-padding">
					
					<div class="">
						
						<label>Foto </label>

						<input class="w3-input w3-border w3-hover-border-black nuevaFoto" type="file" name="registroFoto">

						<img src="vistas/img/default/anonymous.png" class="w3-img w3-padding previsualizar" width="100px">

					</div>

				</div>


				<div class="w3-row-padding">
					
					<hr class="w3-xlarge w3-padding w3-border-indigo">
					
				</div>


				<div class="w3-row-padding">
					
					<div class="w3-third">
						
						<input type="submit" class="w3-btn w3-block w3-indigo w3-round" value="Registrar"> 

					</div>

					<div class="w3-third">
						
						<button class="w3-button w3-card-4 w3-round" onclick="document.getElementById('abrirModal').style.display='none'">Cancelar</button>

					</div>

				</div>

				<?php 


					$guardarArchivo = new ControladorArchivos();

					$guardarArchivo -> ctrGuardarArchivo();

				 ?>

			</div>

		</form>

	</div>

</div>

<div class="w3-row-padding">

	<?php 

		$item = null;

		$valor = null;

		$imagen = ControladorArchivos::ctrMostrarImagen($item, $valor);
		// echo '<pre>'; print_r($imagen); echo '</pre>';


	 ?>

	 <?php foreach ($imagen as $key => $value): ?>
	 	
	 	<div class="w3-col l3 m6 w3-margin-bottom">

	 		<div class="w3-display-container">

	 			<div class="w3-display-topleft w3-black w3-padding"><?php echo $value["titulo"]; ?></div>

	 			<img src="<?php echo $value["foto"]; ?>" alt="<?php echo $value["titulo"]; ?>" style="width:100%; height: 300px">

	 			<button onclick="document.getElementById('openModalView').style.display='block'" class="w3-button w3-green w3-round btnEditar" idGalery="<?php echo $value["id"]; ?>"><i class="fa fa-pencil"></i></button>
	 			<button class="w3-button w3-red w3-round w3-round btnEliminar" idGalery="<?php echo $value["id"]; ?>" foto=""><i class="fa fa-trash"></i></button>

	 		</div>

	 	</div>

	 <?php endforeach ?>


</div>



<!--=====================================
editar foto
======================================-->

<div class="w3-modal" id="openModalView">
	
	<div class="w3-modal-content w3-card-4 w3-animate-zoom" style="max-width: 600px">
		
		<div class="w3-container w3-indigo">
			
			<h2 class="w3-center">Editar contenido</h2>

			<span onclick="document.getElementById('openModalView').style.display='none'" class="w3-btn w3-hover-red w3-display-topright" title="Cerrar modal">&times;</span>

		</div>

		<form class="w3-container" method="post" enctype="multipart/form-data">
			
			<div class="w3-section">
				
				<div class="w3-row-padding">
					
					<div class="">
						
						<label>Título </label>

						<input class="w3-input w3-border w3-hover-border-black" type="text" name="editarTitulo" id="editarTitulo"  required>

					</div>

				</div>

				<div class="w3-row-padding">
					
					<div class="">
						
						<label>Usuario </label>

						<input class="w3-input w3-border w3-hover-border-black" type="text" name="editarUsuario" id="editarUsuario"  required>

					</div>

				</div>

				<div class="w3-row-padding">
					
					<div class="">
						
						<label>Foto </label>

						<input class="w3-input w3-border w3-hover-border-black nuevaFoto" type="file" name="editarFoto">

						<img src="vistas/img/default/anonymous.png" class="w3-img w3-padding previsualizarEditar" width="100px">

						<input type="hidden" name="fotoActual" id="fotoActual">

					</div>

				</div>


				<div class="w3-row-padding">
					
					<hr class="w3-xlarge w3-padding w3-border-indigo">
					
				</div>


				<div class="w3-row-padding">
					
					<div class="w3-third">
						
						<input type="submit" class="w3-btn w3-block w3-indigo w3-round" value="Actualizar"> 

					</div>

				</div>

				<?php 


					$editarArchivo = new ControladorArchivos();

					$editarArchivo -> ctrEditarArchivo();

				 ?>

			</div>

		</form>

	</div>

</div>

<?php 

	$eliminar = new ControladorArchivos();

	$eliminar -> ctrEliminarArchivos();

 ?>