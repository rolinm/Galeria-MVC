<div class="w3-container w3-padding-32" id="projects">

	 <h3 class="w3-border-bottom w3-border-light-grey w3-padding-16">Mi Galería | MVC</h3>

</div>

<!--=====================================
botón que abre el modal
======================================-->
