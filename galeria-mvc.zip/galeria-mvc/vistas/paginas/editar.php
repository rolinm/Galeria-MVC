<div class="w3-container">

	<form class="w3-container" method="post" enctype="multipart/form-data">

		<div class="w3-section">

			<?php 

				$item = "id";

				$valor = $_GET["idGalery"];

				$galeriaFile = ControladorArchivos::ctrMostrarImagen($item, $valor);
				echo '<pre>'; print_r($galeriaFile); echo '</pre>';


			 ?>

			<div class="w3-row-padding">

				<div class="">

					<label>Título </label>

					<input class="w3-input w3-border w3-hover-border-black" type="text" name="registroTitulo" value="<?php echo $galeriaFile["titulo"] ?>" required>

				</div>

			</div>

			<div class="w3-row-padding">

				<div class="">

					<label>Usuario </label>

					<input class="w3-input w3-border w3-hover-border-black" type="text" name="registroUsuario" value="<?php echo $galeriaFile["usuario"] ?>" required>

				</div>

			</div>

			<div class="w3-row-padding">

				<div class="">

					<label>Foto </label>

					<input class="w3-input w3-border w3-hover-border-black" type="file" name="registroFoto" value="<?php echo $galeriaFile["foto"] ?>">

				</div>

			</div>


			<div class="w3-row-padding">

				<hr class="w3-xlarge w3-padding w3-border-indigo">

			</div>


			<div class="w3-row-padding">

				<div class="w3-third">

					<input type="submit" class="w3-btn w3-block w3-indigo w3-round" value="Registrar"> 

				</div>

				<div class="w3-third">

					<a href="inicio" class="w3-button w3-card-4 w3-round">Cancelar</a>

				</div>

			</div>

			<?php 



			?>

		</div>

	</form>

</div>