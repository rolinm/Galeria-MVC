<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">

	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>Galeria MVC</title>
	<!--=====================================
	Links de css
	======================================-->

	<link rel="stylesheet" href="vistas/css/w3.css">
	<link rel="stylesheet" href="vistas/css/w3-colors-2020.css">
	<link rel="stylesheet" href="vistas/css/w3-colors-2021.css">
	<link rel="stylesheet" href="vistas/css/w3-colors-flat.css">
	<link rel="stylesheet" href="vistas/css/w3-colors-ios.css">
	<link rel="stylesheet" href="vistas/css/w3-colors-metro.css">
	<link rel="stylesheet" href="vistas/css/w3-colors-win8.css">
	<link rel="stylesheet" href="vistas/css/w3pro.css">

	<!--=====================================
	Links JavaScript
	======================================-->

	<script src="vistas/js/plugins/jquery.min.js"></script>

	<script src="vistas/js/plugins/sweetalert2.all.js"></script>

	<script src="https://kit.fontawesome.com/e632f1f723.js" crossorigin="anonymous"></script>
	
</head>

<body>

	<?php 

		include "paginas/header.php";


	 ?>


	<div class="w3-content w3-padding" style="max-width:1564px">

		<?php 

			include "paginas/section.php";

			if (isset($_GET["ruta"])) {
				
				if ($_GET["ruta"] == "inicio" || $_GET["ruta"] == "editar" || $_GET["ruta"] == "contenido") {
					
					include "paginas/".$_GET["ruta"].".php";

				} else {
					
					include "paginas/modulos/error.php";

				}

			} else {
				
				include "paginas/inicio.php";

			}

		 ?>

	  	

	</div>

</body>

</html>

<script src="vistas/js/galery.js"></script>