<?php  

class ControladorArchivos {

	static public function ctrGuardarArchivo() {

		if (isset($_POST["registroTitulo"])) {
			
			if (preg_match('/^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ ]+$/', $_POST["registroTitulo"]) & preg_match('/^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ ]+$/', $_POST["registroUsuario"])) {
				
				/*===========================================
				Validamos la imagen            =
				===========================================*/
				
				$ruta = "";

				if (isset($_FILES["registroFoto"]["tmp_name"])) {
					
					list($ancho, $alto) = getimagesize($_FILES["registroFoto"]["tmp_name"]);

					$nuevoAlto = 500;
					$nuevoAncho = 700;

					/*===========================================================================
					Creamos el directorio donde vamos a guardar la foto            =
					===========================================================================*/
					
					$directorio = "vistas/img/files/".$_POST["registroUsuario"];

					mkdir($directorio, 0755);

					/*============================================================================
					de acuerdo al tipo de imagen aplicamos su validacion            =
					============================================================================*/
					
					if ($_FILES["registroFoto"]["type"] == "image/jpeg") {
						
						/*============================================================
						=            Guardamos la imagen en el directorio            =
						============================================================*/
						
						$aleatorio = mt_rand(100, 999);

						$ruta = "vistas/img/files/".$_POST["registroUsuario"]."/".$aleatorio.".jpg";

						$origen = imagecreatefromjpeg($_FILES["registroFoto"]["tmp_name"]);

						$destino = imagecreatetruecolor($nuevoAncho, $nuevoAlto);

						imagecopyresized($destino, $origen, 0, 0, 0, 0, $nuevoAncho, $nuevoAlto, $ancho, $alto);

						imagejpeg($destino, $ruta);

					}

					if ($_FILES["registroFoto"]["type"] == "image/png") {
						
						/*============================================================
						=            Guardamos la imagen en el directorio            =
						============================================================*/
						
						$aleatorio = mt_rand(100, 999);

						$ruta = "vistas/img/files/".$_POST["registroUsuario"]."/".$aleatorio.".jpg";

						$origen = imagecreatefrompng($_FILES["registroFoto"]["tmp_name"]);

						$destino = imagecreatetruecolor($nuevoAncho, $nuevoAlto);

						imagecopyresized($destino, $origen, 0, 0, 0, 0, $nuevoAncho, $nuevoAlto, $ancho, $alto);

						imagepng($destino, $ruta);

					}

				}

				$tabla = "file";

				$datos = array("usuario" => $_POST["registroUsuario"],
					           "titulo" => $_POST["registroTitulo"],
					           "foto" => $ruta);

				$respuesta = ModeloArchivos::mdlGuardarArchivos($tabla, $datos);

				if ($respuesta == "ok") {
					
					echo '<script>

						swal({

							type: "success",
							title: "¡Se ha guardado correctamente!",
							showConfirmButton: true,
							confirmButtonText: "Cerrar"

						}).then(function(result){

							if(result.value){
							
								window.location = "contenido";

							}

						});
				

					</script>';

				}

			} else {
				
				echo '<script>

						swal({

							type: "error",
							title: "¡El registro no puede ir vacío o llevar caracteres especiales!",
							showConfirmButton: true,
							confirmButtonText: "Cerrar"

						}).then(function(result){

							if(result.value){
							
								window.location = "contenido";

							}

						});
				

				</script>';

			}

		}

	}

	/*=================================================================
	=            Mostrar las imaágenes de la base de datos            =
	=================================================================*/
	
	static public function ctrMostrarImagen($item, $valor) {

		$tabla = "file";

		$respuesta = ModeloArchivos::mdlMostrarImagenes($tabla, $item, $valor);

		return $respuesta;

	}
	
	/*======================================
	=            editar archivo            =
	======================================*/
	
	static public function ctrEditarArchivo() {

		if (isset($_POST["editarTitulo"])) {
			
			if (preg_match('/^[a-zA-Z0-9ñNáéíóúÁÉÍÓÚ ]+$/', $_POST["editarTitulo"]) && preg_match('/^[a-zA-ZñÑáéíóúÁÉÍÓÚ ]+$/', $_POST["editarUsuario"])) {
				
				/*===========================================
				=            validamos la imagen            =
				===========================================*/
				
				$ruta = $_POST["fotoActual"];


				if(isset($_FILES["editarFoto"]["tmp_name"]) && !empty($_FILES["editarFoto"]["tmp_name"])){

					list($ancho, $alto) = getimagesize($_FILES["editarFoto"]["tmp_name"]);

					$nuevoAncho = 500;
					$nuevoAlto = 700;

					/*=============================================
					CREAMOS EL DIRECTORIO DONDE VAMOS A GUARDAR LA FOTO DEL USUARIO
					=============================================*/

					$directorio = "vistas/img/files/".$_POST["editarUsuario"];

					/*=============================================
					PRIMERO PREGUNTAMOS SI EXISTE OTRA IMAGEN EN LA BD
					=============================================*/

					if(!empty($_POST["fotoActual"])){

						unlink($_POST["fotoActual"]);

					}else{

						mkdir($directorio, 0755);

					}	

					/*=============================================
					DE ACUERDO AL TIPO DE IMAGEN APLICAMOS LAS FUNCIONES POR DEFECTO DE PHP
					=============================================*/

					if($_FILES["editarFoto"]["type"] == "image/jpeg"){

						/*=============================================
						GUARDAMOS LA IMAGEN EN EL DIRECTORIO
						=============================================*/

						$aleatorio = mt_rand(100,999);

						$ruta = "vistas/img/files/".$_POST["editarUsuario"]."/".$aleatorio.".jpg";

						$origen = imagecreatefromjpeg($_FILES["editarFoto"]["tmp_name"]);						

						$destino = imagecreatetruecolor($nuevoAncho, $nuevoAlto);

						imagecopyresized($destino, $origen, 0, 0, 0, 0, $nuevoAncho, $nuevoAlto, $ancho, $alto);

						imagejpeg($destino, $ruta);

					}

					if($_FILES["editarFoto"]["type"] == "image/png"){

						/*=============================================
						GUARDAMOS LA IMAGEN EN EL DIRECTORIO
						=============================================*/

						$aleatorio = mt_rand(100,999);

						$ruta = "vistas/img/files/".$_POST["editarUsuario"]."/".$aleatorio.".png";

						$origen = imagecreatefrompng($_FILES["editarFoto"]["tmp_name"]);						

						$destino = imagecreatetruecolor($nuevoAncho, $nuevoAlto);

						imagecopyresized($destino, $origen, 0, 0, 0, 0, $nuevoAncho, $nuevoAlto, $ancho, $alto);

						imagepng($destino, $ruta);

					}

				}

				$tabla = "file";

				$datos = array("usuario" => $_POST["editarUsuario"],
					           "titulo" => $_POST["editarTitulo"],
					           "foto" => $ruta);

				$respuesta = ModeloArchivos::mdlActualizarFoto($tabla, $datos);

				if ($respuesta == "ok") {
					
					echo '<script>

						swal({

							type: "success",
							title: "¡Se ha actualizado correctamente!",
							showConfirmButton: true,
							confirmButtonText: "Cerrar"

						}).then(function(result){

							if(result.value){
							
								window.location = "contenido";

							}

						});
				

					</script>';

				}



			} else {
				
				echo '<script>

						swal({

							type: "error",
							title: "¡El registro no puede ir vacío o llevar caracteres especiales!",
							showConfirmButton: true,
							confirmButtonText: "Cerrar"

						}).then(function(result){

							if(result.value){
							
								window.location = "contenido";

							}

						});
				

				</script>';

			}

		}

	}
	

	/*======================================
	=            eliminar fotos            =
	======================================*/
	
	static public function ctrEliminarArchivos() {

		if (isset($_GET["idGaleria"])) {
			
			$tabla = "file";

			$datos = $_GET["idGaleria"];

			$respuesta = ModeloArchivos::mdlEliminarArchivos($tabla, $datos);

			if ($respuesta == "ok") {
				
				echo '<script>

						swal({

							type: "success",
							title: "¡El archivo ha sido borrado correctamente!",
							showConfirmButton: true,
							confirmButtonText: "Cerrar"

						}).then(function(result){

							if(result.value){
							
								window.location = "contenido";

							}

						});
				

				</script>';

			}

		}

	}
	
}