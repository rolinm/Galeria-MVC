<?php

class ControladorPlantilla {

	public function ctrTraerPlantilla() {

		include "vistas/plantilla.php";

	}

}