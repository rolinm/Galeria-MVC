<?php

require_once "../controladores/archivos.controlador.php";
require_once "../modelos/archivos.modelo.php";

class ajaxGaleria {

	/*===========================================
	=            editar el contenido            =
	===========================================*/
	
	public $idGaleria;

	public function ajaxEditarGaleria() {

		$item = "id";

		$valor = $this->idGaleria;

		$respuesta = ControladorArchivos::ctrMostrarImagen($item, $valor);

		echo json_encode($respuesta);

	}
	

}

/*===================================================
=            Activamos el editar usuario            =
===================================================*/

if (isset($_POST["idGaleria"])) {
	
	$editar = new ajaxGaleria();
	$editar -> idGaleria = $_POST["idGaleria"];
	$editar -> ajaxEditarGaleria();
}
